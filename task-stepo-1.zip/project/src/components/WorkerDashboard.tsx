import React from 'react';
import { useAuthStore } from '../store/authStore';
import { Currency as CurrencyEth, LogOut, Share2, Upload } from 'lucide-react';

export function WorkerDashboard() {
  const { user, signOut } = useAuthStore();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                {user?.profile_image_url ? (
                  <img 
                    src={user.profile_image_url} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-indigo-100 text-indigo-600 font-semibold">
                    {user?.email?.[0]?.toUpperCase()}
                  </div>
                )}
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">{user?.full_name || 'Worker'}</h2>
                <p className="text-sm text-gray-500">{user?.email}</p>
              </div>
            </div>
            <button
              onClick={() => signOut()}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <LogOut className="w-5 h-5 mr-2" />
              Sign Out
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Balance Card */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Available Balance</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {user?.balance?.toFixed(2) || '0.00'} Birr
              </h3>
            </div>
            <div className="flex space-x-4">
              <button className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                <Upload className="w-5 h-5 mr-2" />
                Deposit
              </button>
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <CurrencyEth className="w-5 h-5 mr-2" />
                Withdraw
              </button>
            </div>
          </div>
        </div>

        {/* Task Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Today's Tasks</h4>
            <div className="flex items-end justify-between">
              <div>
                <p className="text-3xl font-bold text-indigo-600">0</p>
                <p className="text-sm text-gray-500">Completed</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-gray-400">0</p>
                <p className="text-sm text-gray-500">Remaining</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Total Earnings</h4>
            <p className="text-3xl font-bold text-green-600">0.00 Birr</p>
            <p className="text-sm text-gray-500">Lifetime earnings</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Referrals</h4>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold text-purple-600">0</p>
                <p className="text-sm text-gray-500">Total referrals</p>
              </div>
              <button className="flex items-center px-4 py-2 bg-purple-100 text-purple-600 rounded-lg hover:bg-purple-200">
                <Share2 className="w-5 h-5 mr-2" />
                Invite
              </button>
            </div>
          </div>
        </div>

        {/* Task List */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Available Tasks</h3>
          </div>
          <div className="p-6">
            <div className="text-center py-12">
              <p className="text-gray-500">No tasks available at the moment.</p>
              <p className="text-sm text-gray-400">Check back later for new tasks</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}