import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useThemeStore } from '../store/themeStore';
import { 
  Youtube, 
  Download, 
  MessageCircle, 
  Instagram, 
  Globe, 
  ChevronRight,
  Facebook,
  Linkedin,
  Send,
  PlayCircle,
  Award,
  Upload,
  BookText as TikTok,
  Mail,
  Newspaper,
  Moon,
  Sun
} from 'lucide-react';

export function LandingPage() {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [selectedCertificate, setSelectedCertificate] = useState<File | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const { isDarkMode, toggleTheme } = useThemeStore();
  
  const languages = [
    { code: 'en', name: 'English' },
    { code: 'am', name: 'አማርኛ' },
    { code: 'om', name: 'Oromifa' },
    { code: 'ti', name: 'ትግርኛ' }
  ];

  const features = [
    {
      icon: <Youtube className="w-8 h-8 text-red-500" />,
      title: t('YouTube Tasks'),
      description: t('Engage with YouTube content and earn rewards')
    },
    {
      icon: <TikTok className="w-8 h-8 text-black dark:text-white" />,
      title: t('TikTok Tasks'),
      description: t('Create and engage with TikTok content')
    },
    {
      icon: <Mail className="w-8 h-8 text-blue-600" />,
      title: t('Gmail Tasks'),
      description: t('Email management and organization tasks')
    },
    {
      icon: <Download className="w-8 h-8 text-blue-500" />,
      title: t('App Downloads'),
      description: t('Download and review apps for compensation')
    },
    {
      icon: <MessageCircle className="w-8 h-8 text-blue-400" />,
      title: t('Telegram Tasks'),
      description: t('Join groups and participate in Telegram activities')
    },
    {
      icon: <Instagram className="w-8 h-8 text-pink-500" />,
      title: t('Instagram Engagement'),
      description: t('Follow, like, and comment on Instagram')
    },
    {
      icon: <Globe className="w-8 h-8 text-green-500" />,
      title: t('Website Tasks'),
      description: t('Visit websites and complete specific actions')
    },
    {
      icon: <Linkedin className="w-8 h-8 text-blue-600" />,
      title: t('LinkedIn Tasks'),
      description: t('Engage with LinkedIn content and grow networks')
    },
    {
      icon: <Newspaper className="w-8 h-8 text-gray-600 dark:text-gray-300" />,
      title: t('Content Writing'),
      description: t('Create engaging content and articles')
    }
  ];

  const steps = [
    {
      number: '01',
      title: t('Sign Up'),
      description: t('Create your account as a Worker or Hire')
    },
    {
      number: '02',
      title: t('Choose Tasks'),
      description: t('Browse available tasks or post your requirements')
    },
    {
      number: '03',
      title: t('Complete Work'),
      description: t('Follow instructions and submit your work')
    },
    {
      number: '04',
      title: t('Get Paid'),
      description: t('Receive payment through CBE or Telebirr')
    }
  ];

  const handleCertificateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedCertificate(e.target.files[0]);
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedVideo(e.target.files[0]);
      if (videoRef.current) {
        videoRef.current.src = URL.createObjectURL(e.target.files[0]);
      }
    }
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gradient-to-b from-gray-50 to-white'}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Globe className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">Task Stack</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {isDarkMode ? (
                  <Sun className="w-5 h-5 text-yellow-500" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-600" />
                )}
              </button>
              
              <select
                onChange={(e) => i18n.changeLanguage(e.target.value)}
                value={i18n.language}
                className="bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md px-3 py-1.5 text-sm dark:text-white"
              >
                {languages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
              
              <button
                onClick={() => navigate('/auth')}
                className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                {t('Get Started')}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            {t('Earn Money Completing Digital Tasks')}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-10 max-w-3xl mx-auto">
            {t('Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.')}
          </p>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => navigate('/auth')}
              className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center"
            >
              {t('Start Earning')} <ChevronRight className="ml-2 w-5 h-5" />
            </button>
            <button
              onClick={() => navigate('/auth')}
              className="border-2 border-indigo-600 text-indigo-600 dark:text-indigo-400 px-8 py-3 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors flex items-center"
            >
              {t('Post Tasks')} <ChevronRight className="ml-2 w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Promotion Section */}
      <section className="bg-gray-100 dark:bg-gray-800 py-12 mb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-semibold text-gray-600 dark:text-gray-300">
              Advertisement Space
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-700 rounded-lg p-8 text-center shadow-sm">
              <p className="text-gray-500 dark:text-gray-300">Available for Ads</p>
              <div className="w-full h-32 bg-gray-100 dark:bg-gray-600 rounded-lg mt-4 flex items-center justify-center">
                <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg p-8 text-center shadow-sm">
              <p className="text-gray-500 dark:text-gray-300">Available for Ads</p>
              <div className="w-full h-32 bg-gray-100 dark:bg-gray-600 rounded-lg mt-4 flex items-center justify-center">
                <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-700 rounded-lg p-8 text-center shadow-sm">
              <p className="text-gray-500 dark:text-gray-300">Available for Ads</p>
              <div className="w-full h-32 bg-gray-100 dark:bg-gray-600 rounded-lg mt-4 flex items-center justify-center">
                <span className="text-gray-400 dark:text-gray-500">Ad Space</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gray-50 dark:bg-gray-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
            {t('Available Task Categories')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white dark:bg-gray-700 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2 dark:text-white">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-20 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
            {t('How It Works')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{step.number}</span>
                </div>
                <h3 className="text-xl font-semibold mb-2 dark:text-white">{step.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certificate Section */}
      <section className="bg-gray-50 dark:bg-gray-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              {t('View Certificate')}
            </h3>
            <div className="flex items-center justify-center space-x-4">
              <label className="flex items-center px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-600">
                <Award className="w-5 h-5 mr-2 text-indigo-600 dark:text-indigo-400" />
                <span className="dark:text-white">{selectedCertificate ? selectedCertificate.name : t('Choose Certificate')}</span>
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                  onChange={handleCertificateChange}
                />
              </label>
              {selectedCertificate && (
                <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                  {t('View Certificate')}
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Video Guide */}
      <section className="bg-gray-50 dark:bg-gray-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12">
            {t('Watch How It Works')}
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="aspect-w-16 aspect-h-9 bg-gray-200 dark:bg-gray-700 rounded-xl overflow-hidden">
              {selectedVideo ? (
                <video
                  ref={videoRef}
                  controls
                  className="w-full h-full object-cover"
                >
                  <source src={URL.createObjectURL(selectedVideo)} type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <label className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-20 h-20 text-indigo-600 dark:text-indigo-400 mb-4" />
                    <span className="text-gray-600 dark:text-gray-300">{t('Upload Demo Video')}</span>
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={handleVideoChange}
                    />
                  </label>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Globe className="w-8 h-8 text-indigo-400" />
                <span className="text-2xl font-bold">Task Stack</span>
              </div>
              <p className="text-gray-400">
                {t('Your trusted platform for digital task completion and hiring.')}
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">{t('Contact Us')}</h3>
              <div className="space-y-2 text-gray-400">
                <p>{t('Customer Support Available')}</p>
                <p>Email: support@taskstack.com</p>
                <p>Telegram: @TaskStackSupport</p>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">{t('Follow Us')}</h3>
              <div className="flex space-x-4">
                <Facebook className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
                <Instagram className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
                <Linkedin className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
                <Send className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} Task Stack. {t('All rights reserved.')}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}