import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  email: string;
  full_name: string | null;
  phone_number: string | null;
  profile_image_url: string | null;
  balance: number;
  type: 'worker' | 'hire';
}

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, confirmPassword: string, phone_number: string) => Promise<void>;
  signOut: () => Promise<void>;
  loadUser: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ 
        email, 
        password 
      });
      
      if (error) throw error;
      
      if (data.user) {
        const { data: profile, error: profileError } = await supabase
          .from('users')
          .select('id, email, full_name, phone_number, profile_image_url, balance, type')
          .eq('id', data.user.id)
          .single();

        if (profileError) throw profileError;
        if (profile) {
          set({ user: profile });
        }
      }
    } catch (error) {
      console.error('Sign in error:', error);
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Failed to sign in. Please try again.');
    }
  },
  signUp: async (email, password, confirmPassword, phone_number) => {
    if (password !== confirmPassword) {
      throw new Error('Passwords do not match');
    }
    
    if (!phone_number.match(/^\+251[0-9]{9}$/)) {
      throw new Error('Invalid phone number format. Must start with +251');
    }

    try {
      // First, create the auth user
      const { data: { user: authUser }, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (signUpError) throw signUpError;
      if (!authUser) throw new Error('Failed to create user account');

      // Create the user profile
      const { data: profile, error: profileError } = await supabase
        .from('users')
        .insert([
          {
            id: authUser.id,
            email: authUser.email,
            phone_number,
            balance: 0,
            type: 'worker' as const
          }
        ])
        .select()
        .single();

      if (profileError) {
        console.error('Profile creation error:', profileError);
        // Clean up the auth user if profile creation fails
        await supabase.auth.signOut();
        throw new Error('Failed to create user profile. Please try again.');
      }

      if (profile) {
        set({ user: profile });
      }

    } catch (error) {
      console.error('Sign up error:', error);
      // Clean up on any error
      await supabase.auth.signOut();
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Failed to create account. Please try again.');
    }
  },
  signOut: async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      set({ user: null });
    } catch (error) {
      console.error('Sign out error:', error);
      throw new Error('Failed to sign out. Please try again.');
    }
  },
  loadUser: async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: profile, error: profileError } = await supabase
          .from('users')
          .select('id, email, full_name, phone_number, profile_image_url, balance, type')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;
        if (profile) {
          set({ user: profile });
        }
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      set({ loading: false });
    }
  },
}));