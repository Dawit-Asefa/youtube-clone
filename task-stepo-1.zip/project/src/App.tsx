import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { useThemeStore } from './store/themeStore';
import { AuthForm } from './components/AuthForm';
import { LandingPage } from './components/LandingPage';
import { WorkerDashboard } from './components/WorkerDashboard';
import { HireDashboard } from './components/HireDashboard';
import { AdminDashboard } from './components/AdminDashboard';

function App() {
  const { user, loading, loadUser } = useAuthStore();
  const { isDarkMode } = useThemeStore();

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center dark:bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-600 border-t-transparent"></div>
      </div>
    );
  }

  const isAdmin = user?.email === 'dabobet@gmail.com';

  return (
    <Router>
      <div className={isDarkMode ? 'dark' : ''}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route
            path="/auth"
            element={user ? <Navigate to="/dashboard" replace /> : <AuthForm />}
          />
          <Route
            path="/dashboard"
            element={
              user ? (
                isAdmin ? (
                  <AdminDashboard />
                ) : (
                  user.type === 'worker' ? (
                    <WorkerDashboard />
                  ) : (
                    <HireDashboard />
                  )
                )
              ) : (
                <Navigate to="/auth" replace />
              )
            }
          />
          <Route
            path="*"
            element={<Navigate to="/" replace />}
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App