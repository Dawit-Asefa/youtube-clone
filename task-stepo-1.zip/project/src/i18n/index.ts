import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: {
          'Get Started': 'Get Started',
          'Post Tasks': 'Post Tasks',
          'Start Earning': 'Start Earning',
          'Earn Money Completing Digital Tasks': 'Earn Money Completing Digital Tasks',
          'Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.': 'Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.',
          'Available Task Categories': 'Available Task Categories',
          'YouTube Tasks': 'YouTube Tasks',
          'Engage with YouTube content and earn rewards': 'Engage with YouTube content and earn rewards',
          'App Downloads': 'App Downloads',
          'Download and review apps for compensation': 'Download and review apps for compensation',
          'Telegram Tasks': 'Telegram Tasks',
          'Join groups and participate in Telegram activities': 'Join groups and participate in Telegram activities',
          'Instagram Engagement': 'Instagram Engagement',
          'Follow, like, and comment on Instagram': 'Follow, like, and comment on Instagram',
          'Website Tasks': 'Website Tasks',
          'Visit websites and complete specific actions': 'Visit websites and complete specific actions',
          'LinkedIn Tasks': 'LinkedIn Tasks',
          'Engage with LinkedIn content and grow networks': 'Engage with LinkedIn content and grow networks',
          'How It Works': 'How It Works',
          'Sign Up': 'Sign Up',
          'Create your account as a Worker or Hire': 'Create your account as a Worker or Hire',
          'Choose Tasks': 'Choose Tasks',
          'Browse available tasks or post your requirements': 'Browse available tasks or post your requirements',
          'Complete Work': 'Complete Work',
          'Follow instructions and submit your work': 'Follow instructions and submit your work',
          'Get Paid': 'Get Paid',
          'Receive payment through CBE or Telebirr': 'Receive payment through CBE or Telebirr',
          'Watch How It Works': 'Watch How It Works',
          'Contact Us': 'Contact Us',
          'Customer Support Available': 'Customer Support Available',
          'Follow Us': 'Follow Us',
          'All rights reserved.': 'All rights reserved.',
          'Your trusted platform for digital task completion and hiring.': 'Your trusted platform for digital task completion and hiring.',
          'View Certificate': 'View Certificate',
          'Upload Demo Video': 'Upload Demo Video'
        }
      },
      am: {
        translation: {
          'Get Started': 'ጀምር',
          'Post Tasks': 'ስራ ጥፍ',
          'Start Earning': 'ስራ ይጀምሩ',
          'Earn Money Completing Digital Tasks': 'ዲጂታል ተግባራትን በማጠናቀቅ ገንዘብ ያግኙ',
          'Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.': 'ቀላል ዲጂታል ተግባራትን በማጠናቀቅ ገንዘብ ለማግኘት ወይም ለዲጂታል ተሳትፎ ፍላጎቶችዎ ሰራተኞችን ለመቅጠር የተግባር ቁልል ይቀላቀሉ።',
          'Available Task Categories': 'የሚገኙ የተግባር ምድቦች',
          'View Certificate': 'የምስክር ወረቀት ይመልከቱ',
          'Upload Demo Video': 'የናሙና ቪዲዮ ያስገቡ'
        }
      },
      om: {
        translation: {
          'Get Started': 'jalqabi',
          'Post Tasks': 'Faankishinii poostaa',
          'Start Earning': 'galii argachuu jalqabuu',
          'Earn Money Completing Digital Tasks': 'Hojii Dijitaalaa Xumuruun Maallaqa Argachuu',
          'Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.': 'Hojiiwwan dijitaalaa salphaa xumuruun ykn hojjettoota fedhii hirmaannaa dijitaalaa keessaniif qacaruun maallaqa argachuuf Task Stack tti makamaa.',
          'Available Task Categories': 'Gosoota Hojii Argaman',
          'View Certificate': 'Ragaa Ilaali',
          'Upload Demo Video': 'Viidiyoo Agarsiisaa Olkaa'
        }
      },
      ti: {
        translation: {
          'Get Started': 'ጀምር',
          'Post Tasks': 'ተጣባቒ ተግባር',
          'Start Earning': 'ምእካብ ጀምር',
          'Earn Money Completing Digital Tasks': 'ዲጂታላዊ ዕማማት ብምፍጻም ገንዘብ ምርካብ',
          'Join Task Stack to earn money by completing simple digital tasks or hire workers for your digital engagement needs.': 'ቀለልቲ ዲጂታላዊ ዕማማት ብምፍጻም ገንዘብ ንምርካብ ወይ ንዲጂታላዊ ጽምዶ ድሌታትኩም ሰራሕተኛታት ምቑጻር ገንዘብ ንምርካብ ኣብ Task Stack ተጸንበሩ።',
          'Available Task Categories': 'ዝርከቡ ምድባት ዕማም',
          'View Certificate': 'ምስክር ወረቐት ርአ',
          'Upload Demo Video': 'ናሙና ቪድዮ ጸዓን'
        }
      }
    },
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;