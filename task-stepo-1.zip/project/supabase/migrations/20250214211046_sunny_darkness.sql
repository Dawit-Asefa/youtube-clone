/*
  # Safe Schema Setup for Task Stack

  This migration safely creates tables and policies if they don't exist.
  Uses DO blocks to safely add columns and constraints.
*/

DO $$ 
BEGIN
    -- Create tables if they don't exist
    CREATE TABLE IF NOT EXISTS users (
        id uuid PRIMARY KEY DEFAULT auth.uid(),
        email text UNIQUE NOT NULL,
        phone_number text,
        full_name text,
        profile_image_url text,
        balance numeric DEFAULT 0,
        created_at timestamptz DEFAULT now()
    );

    -- Add phone number constraint if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'phone_number_format'
    ) THEN
        ALTER TABLE users 
        ADD CONSTRAINT phone_number_format 
        CHECK (phone_number ~ '^\+251[0-9]{9}$');
    END IF;

    -- Create tasks table if it doesn't exist
    CREATE TABLE IF NOT EXISTS tasks (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        title text NOT NULL,
        description text,
        amount numeric NOT NULL,
        status text NOT NULL DEFAULT 'available',
        locked_until timestamptz,
        locked_by uuid REFERENCES users(id),
        completed_by uuid REFERENCES users(id),
        created_at timestamptz DEFAULT now()
    );

    -- Add status constraint if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'valid_status'
    ) THEN
        ALTER TABLE tasks 
        ADD CONSTRAINT valid_status 
        CHECK (status IN ('available', 'locked', 'completed', 'approved', 'rejected'));
    END IF;

    -- Create deposits table if it doesn't exist
    CREATE TABLE IF NOT EXISTS deposits (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id uuid REFERENCES users(id) NOT NULL,
        amount numeric NOT NULL,
        full_name text NOT NULL,
        phone_number text NOT NULL,
        status text NOT NULL DEFAULT 'pending',
        reviewed_by uuid REFERENCES users(id),
        created_at timestamptz DEFAULT now()
    );

    -- Add deposit constraints if they don't exist
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'deposits_valid_status'
    ) THEN
        ALTER TABLE deposits 
        ADD CONSTRAINT deposits_valid_status 
        CHECK (status IN ('pending', 'approved', 'rejected'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'deposits_phone_number_format'
    ) THEN
        ALTER TABLE deposits 
        ADD CONSTRAINT deposits_phone_number_format 
        CHECK (phone_number ~ '^\+251[0-9]{9}$');
    END IF;

    -- Create withdrawals table if it doesn't exist
    CREATE TABLE IF NOT EXISTS withdrawals (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id uuid REFERENCES users(id) NOT NULL,
        amount numeric NOT NULL,
        status text NOT NULL DEFAULT 'pending',
        reviewed_by uuid REFERENCES users(id),
        created_at timestamptz DEFAULT now()
    );

    -- Add withdrawal status constraint if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'withdrawals_valid_status'
    ) THEN
        ALTER TABLE withdrawals 
        ADD CONSTRAINT withdrawals_valid_status 
        CHECK (status IN ('pending', 'approved', 'rejected'));
    END IF;

    -- Create referrals table if it doesn't exist
    CREATE TABLE IF NOT EXISTS referrals (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        referrer_id uuid REFERENCES users(id) NOT NULL,
        referred_username text NOT NULL,
        status text NOT NULL DEFAULT 'pending',
        created_at timestamptz DEFAULT now()
    );

    -- Add referral status constraint if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_constraint 
        WHERE conname = 'referrals_valid_status'
    ) THEN
        ALTER TABLE referrals 
        ADD CONSTRAINT referrals_valid_status 
        CHECK (status IN ('pending', 'approved', 'rejected'));
    END IF;
END $$;

-- Enable RLS on all tables if not already enabled
ALTER TABLE IF EXISTS users ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS referrals ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and create new ones
DO $$ 
BEGIN
    -- Users policies
    DROP POLICY IF EXISTS "Users can read own data" ON users;
    DROP POLICY IF EXISTS "Users can update own data" ON users;
    DROP POLICY IF EXISTS "Admins can read all users" ON users;

    CREATE POLICY "Users can read own data"
        ON users FOR SELECT
        TO authenticated
        USING (auth.uid() = id);

    CREATE POLICY "Users can update own data"
        ON users FOR UPDATE
        TO authenticated
        USING (auth.uid() = id);

    -- Tasks policies
    DROP POLICY IF EXISTS "Anyone can read available tasks" ON tasks;
    DROP POLICY IF EXISTS "Users can update tasks they locked" ON tasks;
    DROP POLICY IF EXISTS "Admins can read all tasks" ON tasks;
    DROP POLICY IF EXISTS "Admins can update all tasks" ON tasks;

    CREATE POLICY "Anyone can read available tasks"
        ON tasks FOR SELECT
        TO authenticated
        USING (status = 'available' OR locked_by = auth.uid() OR completed_by = auth.uid());

    CREATE POLICY "Users can update tasks they locked"
        ON tasks FOR UPDATE
        TO authenticated
        USING (locked_by = auth.uid());

    -- Deposits policies
    DROP POLICY IF EXISTS "Users can read own deposits" ON deposits;
    DROP POLICY IF EXISTS "Users can create deposits" ON deposits;
    DROP POLICY IF EXISTS "Admins can read all deposits" ON deposits;
    DROP POLICY IF EXISTS "Admins can update deposits" ON deposits;

    CREATE POLICY "Users can read own deposits"
        ON deposits FOR SELECT
        TO authenticated
        USING (user_id = auth.uid());

    CREATE POLICY "Users can create deposits"
        ON deposits FOR INSERT
        TO authenticated
        WITH CHECK (user_id = auth.uid());

    -- Withdrawals policies
    DROP POLICY IF EXISTS "Users can read own withdrawals" ON withdrawals;
    DROP POLICY IF EXISTS "Users can create withdrawals" ON withdrawals;
    DROP POLICY IF EXISTS "Admins can read all withdrawals" ON withdrawals;
    DROP POLICY IF EXISTS "Admins can update withdrawals" ON withdrawals;

    CREATE POLICY "Users can read own withdrawals"
        ON withdrawals FOR SELECT
        TO authenticated
        USING (user_id = auth.uid());

    CREATE POLICY "Users can create withdrawals"
        ON withdrawals FOR INSERT
        TO authenticated
        WITH CHECK (user_id = auth.uid());

    -- Referrals policies
    DROP POLICY IF EXISTS "Users can read own referrals" ON referrals;
    DROP POLICY IF EXISTS "Users can create referrals" ON referrals;
    DROP POLICY IF EXISTS "Admins can read all referrals" ON referrals;
    DROP POLICY IF EXISTS "Admins can update referrals" ON referrals;

    CREATE POLICY "Users can read own referrals"
        ON referrals FOR SELECT
        TO authenticated
        USING (referrer_id = auth.uid());

    CREATE POLICY "Users can create referrals"
        ON referrals FOR INSERT
        TO authenticated
        WITH CHECK (referrer_id = auth.uid());
END $$;

-- Create or replace admin function
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM users 
        WHERE id = user_id 
        AND email = 'admin@taskstack.com'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create admin policies
DO $$
BEGIN
    -- Users admin policies
    CREATE POLICY "Admins can read all users"
        ON users FOR SELECT
        TO authenticated
        USING (is_admin(auth.uid()));

    -- Tasks admin policies
    CREATE POLICY "Admins can read all tasks"
        ON tasks FOR SELECT
        TO authenticated
        USING (is_admin(auth.uid()));

    CREATE POLICY "Admins can update all tasks"
        ON tasks FOR UPDATE
        TO authenticated
        USING (is_admin(auth.uid()));

    -- Deposits admin policies
    CREATE POLICY "Admins can read all deposits"
        ON deposits FOR SELECT
        TO authenticated
        USING (is_admin(auth.uid()));

    CREATE POLICY "Admins can update deposits"
        ON deposits FOR UPDATE
        TO authenticated
        USING (is_admin(auth.uid()));

    -- Withdrawals admin policies
    CREATE POLICY "Admins can read all withdrawals"
        ON withdrawals FOR SELECT
        TO authenticated
        USING (is_admin(auth.uid()));

    CREATE POLICY "Admins can update withdrawals"
        ON withdrawals FOR UPDATE
        TO authenticated
        USING (is_admin(auth.uid()));

    -- Referrals admin policies
    CREATE POLICY "Admins can read all referrals"
        ON referrals FOR SELECT
        TO authenticated
        USING (is_admin(auth.uid()));

    CREATE POLICY "Admins can update referrals"
        ON referrals FOR UPDATE
        TO authenticated
        USING (is_admin(auth.uid()));
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;