/*
  # Add user type column

  1. Changes
    - Add 'type' column to users table with valid values 'worker' or 'hire'
    - Set default value to 'worker'
    - Add check constraint to ensure valid values

  2. Security
    - No changes to existing RLS policies needed
*/

DO $$ 
BEGIN
  -- Add type column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'users' 
    AND column_name = 'type'
  ) THEN
    ALTER TABLE users 
    ADD COLUMN type text NOT NULL DEFAULT 'worker';

    -- Add check constraint for valid types
    ALTER TABLE users 
    ADD CONSTRAINT valid_user_type 
    CHECK (type IN ('worker', 'hire'));
  END IF;
END $$;