/*
  # Initial Schema for Task Stack

  1. New Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - phone_number (text)
      - full_name (text)
      - profile_image_url (text)
      - balance (numeric, default 0)
      - created_at (timestamp)
      
    - tasks
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - amount (numeric)
      - status (text)
      - locked_until (timestamp)
      - locked_by (uuid, references users)
      - completed_by (uuid, references users)
      - created_at (timestamp)
      
    - deposits
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - amount (numeric)
      - full_name (text)
      - phone_number (text)
      - status (text)
      - reviewed_by (uuid, references users)
      - created_at (timestamp)
      
    - withdrawals
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - amount (numeric)
      - status (text)
      - reviewed_by (uuid, references users)
      - created_at (timestamp)
      
    - referrals
      - id (uuid, primary key)
      - referrer_id (uuid, references users)
      - referred_username (text)
      - status (text)
      - created_at (timestamp)
      
  2. Security
    - Enable RLS on all tables
    - Add policies for user access
*/

-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT auth.uid(),
  email text UNIQUE NOT NULL,
  phone_number text,
  full_name text,
  profile_image_url text,
  balance numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT phone_number_format CHECK (phone_number ~ '^\+251[0-9]{9}$')
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Tasks table
CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'available',
  locked_until timestamptz,
  locked_by uuid REFERENCES users(id),
  completed_by uuid REFERENCES users(id),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('available', 'locked', 'completed', 'approved', 'rejected'))
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read available tasks"
  ON tasks
  FOR SELECT
  TO authenticated
  USING (status = 'available' OR locked_by = auth.uid() OR completed_by = auth.uid());

CREATE POLICY "Users can update tasks they locked"
  ON tasks
  FOR UPDATE
  TO authenticated
  USING (locked_by = auth.uid());

-- Deposits table
CREATE TABLE deposits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  amount numeric NOT NULL,
  full_name text NOT NULL,
  phone_number text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid REFERENCES users(id),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected')),
  CONSTRAINT phone_number_format CHECK (phone_number ~ '^\+251[0-9]{9}$')
);

ALTER TABLE deposits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own deposits"
  ON deposits
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create deposits"
  ON deposits
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Withdrawals table
CREATE TABLE withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid REFERENCES users(id),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected'))
);

ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own withdrawals"
  ON withdrawals
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create withdrawals"
  ON withdrawals
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Referrals table
CREATE TABLE referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid REFERENCES users(id) NOT NULL,
  referred_username text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected'))
);

ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own referrals"
  ON referrals
  FOR SELECT
  TO authenticated
  USING (referrer_id = auth.uid());

CREATE POLICY "Users can create referrals"
  ON referrals
  FOR INSERT
  TO authenticated
  WITH CHECK (referrer_id = auth.uid());

-- Admin functions
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  -- Add admin check logic here
  RETURN EXISTS (
    SELECT 1 FROM users 
    WHERE id = user_id 
    AND email = 'admin@taskstack.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Admin policies
CREATE POLICY "Admins can read all users"
  ON users
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can read all tasks"
  ON tasks
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update all tasks"
  ON tasks
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can read all deposits"
  ON deposits
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update deposits"
  ON deposits
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can read all withdrawals"
  ON withdrawals
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update withdrawals"
  ON withdrawals
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can read all referrals"
  ON referrals
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update referrals"
  ON referrals
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));